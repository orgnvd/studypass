angular.module('appConfig', []).constant('appConfig',{
    "serverAppUrl": "http://13.235.75.243:3000",
    "frontEndUrl": "http://13.235.75.243:8000/studypass/#"
}).factory('ConfigurationHolder',function(appConfig){
    return appConfig;
});